import sys as sys
from os.path import abspath, join, dirname

def main():
    mensaje = '%s %s' % (
        sys.executable,
        abspath(join(dirname(__file__), 'executor.py'))
    )

    print(mensaje)

main()