# Introduction

This directory contains a minimal Mesos framework using `pymesos` and `addict`.


# Acknowledgment

This framework is based on the example from Chapter 10 of `Mesos in action`.
